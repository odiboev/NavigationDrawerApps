package com.lucasurbas.masterdetail.ui.utils

interface BaseNavigator
