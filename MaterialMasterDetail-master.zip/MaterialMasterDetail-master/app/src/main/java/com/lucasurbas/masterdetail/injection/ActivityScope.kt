package com.lucasurbas.masterdetail.injection

import javax.inject.Scope

@Scope
annotation class ActivityScope
