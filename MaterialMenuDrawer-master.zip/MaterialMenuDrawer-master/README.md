MaterialMenuDrawer
==================

This App Project provides some code to implement a Navigation Drawer with Androids appcompat library v21 down to API Level 7. I will add more features soon. Enjoy and feel free to improve this code!

Demo Application:
https://play.google.com/store/apps/details?id=com.brobox.materialmenudrawer
