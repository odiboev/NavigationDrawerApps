package com.brobox.materialmenudrawer.dialog;

import android.support.v4.app.DialogFragment;

/**
 * Created by Daniel on 09.11.2014.
 */
public class Error_Dialog extends DialogFragment {
}
